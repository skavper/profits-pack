bool duiPlayerViewport(int renderer,int viewport,out vec2 size){
if(renderer==0&&viewport==0){size=vec2(48,72);return true;}
if(renderer==0&&viewport==1){size=vec2(72,108);return true;}
if(renderer==0&&viewport==2){size=vec2(108,162);return true;}
if(renderer==0&&viewport==3){size=vec2(144,216);return true;}
size=vec2(0);return false;}
bool duiPlayerPose(int renderer,int pose,out vec4 camera,out vec2 idle,out float limbs[6]){
if(renderer==0&&pose==0){camera=vec4(0.000000000,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
if(renderer==0&&pose==1){camera=vec4(0.785398163,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
if(renderer==0&&pose==2){camera=vec4(1.570796327,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
if(renderer==0&&pose==3){camera=vec4(2.356194490,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
if(renderer==0&&pose==4){camera=vec4(3.141592654,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
if(renderer==0&&pose==5){camera=vec4(3.926990817,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
if(renderer==0&&pose==6){camera=vec4(4.712388980,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
if(renderer==0&&pose==7){camera=vec4(5.497787144,-0.100000000,36.000000000,0.0);idle=vec2(0.035000000,1.800000000);limbs[0]=0.000000000;limbs[1]=0.000000000;limbs[2]=0.000000000;limbs[3]=0.000000000;limbs[4]=0.000000000;limbs[5]=0.000000000;return true;}
camera=vec4(0);idle=vec2(0);for(int i=0;i<6;i++)limbs[i]=0.0;return false;}
