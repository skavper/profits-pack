#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;
layout(location = 10) flat in int duiVideoFormat;layout(location = 11) flat in int duiVideoBackground;layout(location = 12) flat in ivec2 duiVideoSize;layout(location = 13) in vec2 duiVideoPoint;
#include <dui:video-fragment.glsl>


#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 14) in vec2 fxUV;
layout(location = 15) flat in int fxMode;
#ifdef IS_GUI
layout(location = 4) flat in int focusGuard;
layout(location = 5) flat in int playerFlags;
layout(location = 6) in vec2 playerPoint;
layout(location = 7) flat in vec2 playerSize;
#include <dui:player-renderers.glsl>
// Shared orthographic cuboid renderer. Skin UVs use Minecraft's normalized 64x64 layout.
mat3 playerYaw(float a){float c=cos(a),s=sin(a);return mat3(c,0,-s,0,1,0,s,0,c);}
mat3 playerPitch(float a){float c=cos(a),s=sin(a);return mat3(1,0,0,0,c,s,0,-s,c);}
bool playerBox(vec3 ro,vec3 rd,vec3 halfSize,out float t,out vec3 normal,out vec3 point){
    vec3 safe=sign(rd)*max(abs(rd),vec3(.00001));safe=mix(vec3(.00001),safe,notEqual(rd,vec3(0)));
    vec3 a=(-halfSize-ro)/safe,b=(halfSize-ro)/safe;
    vec3 near=min(a,b),far=max(a,b);float enter=max(max(near.x,near.y),near.z),leave=min(min(far.x,far.y),far.z);
    if(leave<max(enter,0.0))return false;
    t=max(enter,0.0);point=ro+rd*t;
    normal=near.x>=near.y&&near.x>=near.z?vec3(-sign(rd.x),0,0):near.y>=near.z?vec3(0,-sign(rd.y),0):vec3(0,0,-sign(rd.z));return true;
}
vec2 playerUv(vec3 p,vec3 normal,vec3 dim,vec2 origin){
    vec3 f=p/dim+vec3(.5);float w=dim.x,h=dim.y,d=dim.z;
    if(normal.z>.5)return origin+vec2(d+f.x*w,d+(1.0-f.y)*h);
    if(normal.z<-.5)return origin+vec2(2.0*d+w+(1.0-f.x)*w,d+(1.0-f.y)*h);
    if(normal.x<-.5)return origin+vec2(f.z*d,d+(1.0-f.y)*h);
    if(normal.x>.5)return origin+vec2(d+w+(1.0-f.z)*d,d+(1.0-f.y)*h);
    if(normal.y>.5)return origin+vec2(d+f.x*w,(1.0-f.z)*d);
    return origin+vec2(d+w+f.x*w,f.z*d);
}
void playerPart(int i,bool slim,out vec3 center,out vec3 dim,out vec2 uv,out vec2 outer){
    if(i==0){center=vec3(0,28,0);dim=vec3(8);uv=vec2(0);outer=vec2(32,0);}
    else if(i==1){center=vec3(0,18,0);dim=vec3(8,12,4);uv=vec2(16,16);outer=vec2(16,32);}
    else if(i==2){center=vec3(slim?-5.5:-6.0,18,0);dim=vec3(slim?3:4,12,4);uv=vec2(40,16);outer=vec2(40,32);}
    else if(i==3){center=vec3(slim?5.5:6.0,18,0);dim=vec3(slim?3:4,12,4);uv=vec2(32,48);outer=vec2(48,48);}
    else if(i==4){center=vec3(-2,6,0);dim=vec3(4,12,4);uv=vec2(0,16);outer=vec2(0,32);}
    else{center=vec3(2,6,0);dim=vec3(4,12,4);uv=vec2(16,48);outer=vec2(0,48);}
}
void playerRay(vec2 q,vec2 size,int flags,out vec3 ro,out vec3 rd){
    vec4 view;vec2 idle;float limbs[6];if(!duiPlayerPose((flags>>10)&15,(flags>>2)&7,view,idle,limbs)){ro=vec3(0);rd=vec3(0,0,-1);return;}
    float scale=size.y/view.z;vec2 p=(q-size*.5)/scale;
    mat3 camera=playerYaw(view.x)*playerPitch(view.y);
    ro=camera*vec3(p.x,-p.y,60)+vec3(0,16,0);rd=camera*vec3(0,0,-1);
}
vec4 playerSkinPixel(sampler2D skin,vec2 q,vec2 size,int flags,float time){
    bool slim=(flags&32)!=0,outerLayer=(flags&64)!=0,idle=(flags&128)!=0;
    vec3 ro,rd;playerRay(q,size,flags,ro,rd);
    vec4 view;vec2 idleParams;float limbs[6];duiPlayerPose((flags>>10)&15,(flags>>2)&7,view,idleParams,limbs);
    float nearest=1e10;vec4 result=vec4(0);
    for(int i=0;i<6;i++){
        vec3 center,dim;vec2 uv,outer;playerPart(i,slim,center,dim,uv,outer);
        mat3 pose=playerPitch(limbs[i]+(idle&&i>=2&&i<=3?sin(time*idleParams.y)*idleParams.x*(i==2?1.0:-1.0):0.0));
        if(idle)center.y+=sin(time*idleParams.y)*.08;
        for(int layer=0;layer<2;layer++){
            if(layer==1&&!outerLayer)continue;
            vec3 expanded=dim+vec3(layer==1?(i==0?1.0:.5):0.0),n,p;float t;
            if(!playerBox(transpose(pose)*(ro-center),transpose(pose)*rd,expanded*.5,t,n,p)||t>=nearest)continue;
            vec2 tex=playerUv(p*dim/expanded,n,dim,layer==0?uv:outer);
            vec4 color=texelFetch(skin,ivec2(clamp(floor(tex),vec2(0),vec2(63))),0);
            if(color.a<.1)continue;
            nearest=t;float light=.65+.35*max(0.0,dot(pose*n,normalize(vec3(-.45,.8,1))));
            result=vec4(color.rgb*light,color.a);
        }
    }
    return result;
}
vec4 playerArmorPixel(sampler2D atlas,vec2 q,vec2 size,int flags,float time){
    bool slim=(flags&32)!=0,idle=(flags&128)!=0;int slot=(flags>>8)&3;
    vec3 ro,rd;playerRay(q,size,flags,ro,rd);
    vec4 view;vec2 idleParams;float limbs[6];duiPlayerPose((flags>>10)&15,(flags>>2)&7,view,idleParams,limbs);
    float nearest=1e10,bodyNearest=1e10;vec4 result=vec4(0);
    for(int i=0;i<6;i++){
        vec3 center,dim;vec2 uv,outer;playerPart(i,slim,center,dim,uv,outer);
        mat3 pose=playerPitch(limbs[i]+(idle&&i>=2&&i<=3?sin(time*idleParams.y)*idleParams.x*(i==2?1.0:-1.0):0.0));
        if(idle)center.y+=sin(time*idleParams.y)*.08;
        vec3 n,p;float t;if(playerBox(transpose(pose)*(ro-center),transpose(pose)*rd,dim*.5,t,n,p))bodyNearest=min(bodyNearest,t);
    }
    for(int i=0;i<6;i++){
        if(slot==0&&i!=0||slot==1&&(i<1||i>3)||slot==2&&i!=1&&i<4||slot==3&&i<4)continue;
        vec3 center,dim;vec2 uv,outer;playerPart(i,slim,center,dim,uv,outer);
        if(i==3){uv=vec2(40,16);}if(i>=4)uv=vec2(0,16);
        if(i==2||i==3)dim.x=4.0;
        mat3 pose=playerPitch(limbs[i]+(idle&&i>=2&&i<=3?sin(time*idleParams.y)*idleParams.x*(i==2?1.0:-1.0):0.0));
        if(idle)center.y+=sin(time*idleParams.y)*.08;
        vec3 expanded=dim+vec3(slot==2?1.0:2.0),n,p;float t;
        if(!playerBox(transpose(pose)*(ro-center),transpose(pose)*rd,expanded*.5,t,n,p)||t>=nearest||t>bodyNearest+.001)continue;
        if(i==3||i==5)p.x=-p.x;
        vec2 tex=playerUv(p*dim/expanded,n,dim,uv)/vec2(64,32);
        vec2 samplePoint=(vec2(6)+tex*36.0)/48.0;samplePoint.y=1.0-samplePoint.y;
        vec4 color=texture(atlas,samplePoint);if(color.a<.1)continue;
        nearest=t;float light=.65+.35*max(0.0,dot(pose*n,normalize(vec3(-.45,.8,1))));result=vec4(color.rgb*light,color.a);
    }
    return result;
}

layout(location = 8) flat in vec2 guardSize;
layout(location = 9) in vec2 guardPoint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

// All DUI and vanilla paths participate in the same 26.3 transparency passes.
void duiWriteColor(vec4 color, bool fogged) {
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    if (fogged) {
#ifdef OIT_ACCUMULATE
        vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
        vec4 fogColor = FogColor;
#endif
        color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    }
#endif
    fragColor = color;
#endif
}

// ---- Profits text effects: per-pixel parts (generated by tools/profits-pack/gen-textfx.cjs) ----
// mode 1 = shine band sweeping every 3 s; mode 2 = lightning: every 3 s a fast jagged white bolt crosses the text
// in 0.28 s while the whole text flashes twice (strike + flicker 0.2 s later).
const float FX_LTAU = 6.2831853;

float fxH2(vec2 q) {
    return fract(sin(dot(q, vec2(127.1, 311.7))) * 43758.5453);
}

// Autumn Limited, mode 3 = living flame: uv.x along the text, uv.y 0 top 1 bottom, tx = the glyph's texel (font pixel).
vec3 fxLimFrag(vec3 c, vec2 uv, float t) {
    float sh = texture(Sampler0, texCoord0).r;
    vec2 tx = floor(texCoord0 * vec2(textureSize(Sampler0, 0)));
    float h = 1.0 - uv.y;
    float x = uv.x * 16.0;
    float n = 0.5 + 0.28 * sin(x * 4.1 + FX_LTAU * t / 0.6) + 0.16 * sin(x * 9.3 - FX_LTAU * t / 0.4) + 0.1 * sin(x * 1.7 + FX_LTAU * t / 1.5);
    float heat = clamp(1.3 - h * 1.7 + (n - 0.5) * 1.4 + (fxH2(tx + floor(t * 10.0)) - 0.5) * 0.3, 0.0, 1.0);
    vec3 col = heat < 0.5 ? mix(mix(c / max(sh, 0.05), vec3(0.55, 0.05, 0.04), 0.6), vec3(1.0, 0.42, 0.08), heat * 2.0) : mix(vec3(1.0, 0.42, 0.08), vec3(1.0, 0.86, 0.38), (heat - 0.5) * 2.0);
    if (fxH2(vec2(tx.x, tx.y + floor(t * 14.0))) > 0.975 && h > 0.35) col = vec3(1.0, 0.96, 0.7);
    return col * sh;
}

vec3 fxFrag(int mode, vec3 c, vec2 uv, float time) {
    float t = time * 1200.0;
    if (mode == 3) return fxLimFrag(c, uv, t);
    if (mode == 1) {
        float s = fract(t / 3.0) * 1.6 - 0.3;
        float i = 1.0 - smoothstep(0.0, 0.1, abs(uv.x + 0.12 * uv.y - s));
        return mix(c, vec3(1.0000, 0.9333, 0.8392), i * 0.9);
    }
    float ts = fract(t / 3.0) * 3.0;
    float flash = exp(-ts * 9.0) + 0.7 * exp(-abs(ts - 0.2) * 40.0);
    c = mix(c, vec3(0.8863, 0.8157, 1.0000), clamp(flash, 0.0, 1.0) * 0.55);
    float s = ts / 0.28 * 1.4 - 0.2;
    float jag = abs(fract(uv.y * 1.5 + 0.25) - 0.5) * 0.16;
    float bolt = ts < 0.4 ? 1.0 - smoothstep(0.0, 0.07, abs(uv.x + jag - s)) : 0.0;
    return mix(c, vec3(0.9333, 0.9647, 1.0000), bolt);
}

void main() {
if(duiVideoFormat>=0){duiWriteColor(duiVideoPixel(),false);return;}

#ifdef IS_GUI
    if(playerFlags>=0){vec4 player=playerSkinPixel(Sampler0,playerPoint,playerSize,playerFlags,GameTime*1200.0);if(player.a<.1)discard;duiWriteColor(player*ColorModulator,false);return;}

    if(focusGuard==1){
        if(guardPoint.x>=2.0&&guardPoint.y>=2.0&&guardPoint.x<guardSize.x-2.0&&guardPoint.y<guardSize.y-2.0)discard;
        duiWriteColor(vec4(vertexColor.rgb,1.0)*ColorModulator,false);return;
    }

#endif
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    vec4 color = texColor * vertexColor * ColorModulator;
#ifdef IS_GUI
    if (color.a < 0.01) {
#else
    if (color.a < 0.1) {
#endif
        discard;
    }

    if (fxMode != 0) color.rgb = fxFrag(fxMode, color.rgb, fxUV, GameTime);
    duiWriteColor(color, true);
}
